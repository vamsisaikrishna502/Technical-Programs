package com.bitlabs.arogayasrihospital;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;
public class App 
{
    public static void main( String[] args )throws Exception
    {
    	Patients p=new Patients();
    	DaoInterface Dao=new DaoImpl();
    	Scanner s=new Scanner(System.in);
    	int option=-1;
    	while(option!=0)
    	{
    	System.out.println("Option 1 for Patient Details:");
    	System.out.println("Option 2 for Madicine Details:");
    	System.out.println("Option 3 for View All Patients:");
    	System.out.println("Option 4 for Delete Patient Details:");
    	System.out.println("Option 5 for Update Patient Details:");
    	System.out.println("Option 6 for Get Patient Details by ID:");
    	option=s.nextInt();
    	switch(option)
    	{
    	case 1:
    		System.out.println("Enter Patient ID:");
    		p.setPid(s.nextInt());
    		System.out.println("Enter Patient Name:");
    		p.setPname(s.next());
    		System.out.println("Enter Patient Age:");
    		p.setAge(s.nextInt());
    		System.out.println("Enter Patient Mobile Number:");
    		p.setMobile(s.nextLong());
    		System.out.println("Enter Patient City:");
    		p.setCity(s.next());
    		Dao.patientRegistration(p);
    		break;
    	case 2:
    		Medicins m=new Medicins();
    		System.out.println("Enter Medicine ID:");
    		m.setMid(s.nextInt());
    		System.out.println("Enter Medicine Name:");
    		m.setMname(s.next());
    		System.out.println("Enter Medicine Price:");
    		m.setPrice(s.nextInt());
    		Dao.addingMedicalRecords(m);
    		break;
    	case 3:
    		Dao.viewAllPatients();
    		break;
    	case 4:
    		System.out.println("Enter Patient ID to Delete:");
    		int pid=s.nextInt();
    		Dao.deletePatientById(pid);
    		break;
    	case 5:
    		System.out.println("Update Patient Name:");
    		p.setPname(s.next());
    		System.out.println("Patient ID:");
    		p.setPid(s.nextInt());
    		Dao.updatePatientInfo(p);
    		break;
    	case 6:
    		System.out.println("Get Patient Details by ID");
    		p.setPid(s.nextInt());
    		Dao.getPatientById(p.getPid());
    		break;
    	}
    }
}
}