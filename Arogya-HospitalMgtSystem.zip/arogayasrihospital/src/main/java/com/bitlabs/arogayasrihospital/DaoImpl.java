package com.bitlabs.arogayasrihospital;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
public class DaoImpl implements DaoInterface
{
	Connection con=null;
	public DaoImpl()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Vamsi_ch","root","sespl!@3");
			if(con!=null)
			{
				System.out.println("Connection created");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
public void patientRegistration(Patients p)
	{
		if(con!=null)
		{
			try
			{
				PreparedStatement pstmt=con.prepareStatement("insert into patient values(?,?,?,?,?)");
				pstmt.setInt(1, p.getPid());
				pstmt.setString(2, p.getPname());
				pstmt.setInt(3, p.getAge());
				pstmt.setLong(4, p.getMobile());
				pstmt.setString(5, p.getCity());
				
				int i=pstmt.executeUpdate();
				if(i!=0)
				{
					System.out.println("Patient details added successfully");
				}
			}
				catch(Exception e)
				{
					System.out.println(e);
				}
		}
	}
	
	public void addingMedicalRecords(Medicins m)
	{
		try
		{
			PreparedStatement pstmt=con.prepareStatement("insert into medicine values(?,?,?)");
			pstmt.setInt(1, m.getMid());
			pstmt.setString(2, m.getMname());
			pstmt.setInt(3, m.getPrice());
			
			int i=pstmt.executeUpdate();
			if(i!=0)
			{
				System.out.println("Medicine details added successfully");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
	
	public void viewAllPatients()
	{
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from patient");
			
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+"   "+rs.getString(2)+"     "+rs.getInt(3)+"     "+rs.getLong(4)+"     "+rs.getString(5));
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public void deletePatientById(int pid) 
	{
		try
		{
			Statement stmt=con.createStatement();
			int i=stmt.executeUpdate("delete from patient where pid='"+pid+"'");
			if(i!=0)
			{
				System.out.println("Patient Deleted Successfully");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
	public void updatePatientInfo(Patients p) 
	{
		try
		{
			Statement stmt=con.createStatement();
			int i=stmt.executeUpdate("update patient set pname='"+p.getPname()+"' where pid='"+p.getPid()+"'");
			if(i!=0)
			{
				System.out.println("Patient Details Updated Successfully");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
	public void getPatientById(int pid) 
	{
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from patient where pid='"+pid+"'");
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+"   "+rs.getString(2)+"     "+rs.getInt(3)+"     "+rs.getLong(4)+"     "+rs.getString(5));
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
	
	

