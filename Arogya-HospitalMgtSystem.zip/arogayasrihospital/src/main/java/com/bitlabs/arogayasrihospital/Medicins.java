package com.bitlabs.arogayasrihospital;

public class Medicins 
{
	private int mid;
	private String mname;
	private int price;
	public int getMid()
	{
		return mid;
	}
	public void setMid(int mid) 
	{
		this.mid = mid;
	}
	public String getMname() 
	{
		return mname;
	}
	public void setMname(String mname) 
	{
		this.mname = mname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) 
	{
		this.price = price;
	}
}
