package com.bitlabs.arogayasrihospital;

public interface DaoInterface {
	public void patientRegistration(Patients p);
	public void addingMedicalRecords(Medicins m);
	public void viewAllPatients();
	public void deletePatientById(int pid);
	public void updatePatientInfo(Patients p);
	public void getPatientById(int pid);
}
